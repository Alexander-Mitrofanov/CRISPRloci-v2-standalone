# Scientific and engineering improvements

Implemented improvements include isolated tool runs, full multi-record FASTA support, portable
source IDs, validated machine-readable contracts, dependency pinning/update tooling, checked
coordinate projection, correct terminator significance, Type V motif annotation, explicit
candidate hypotheses, readable feature contributions, GFF3/FASTA exports, input/model/executable
hashes, and failure/completion artifacts. No model retraining was performed.

## Literature-driven changes

The [literature inventory and benchmark](LITERATURE_BENCHMARK.md) adds 304,447 source records,
42,712 distinct normalized sequences, original table locations, evidence labels, source hashes
and explicit training-overlap annotations. Most records are computational predictions; the
catalogue preserves that distinction. It includes the original 41-sequence Briner alignment
and all 521 Chyou predictions, with the paper's 275-record conservative subset labeled separately.
Published native-locus references exposed four concrete
problems that have now been addressed:

1. FASTA36 receives short local input filenames inside each isolated working directory, avoiding
   corruption of long absolute library paths by its legacy parser.
2. Accepted CRISPR arrays are masked in a separate search copy before anti-repeat alignment,
   preventing perfect repeat copies from suppressing weaker external matches. Original bases
   and coordinates are preserved.
3. The redundant whole-genome-as-query FASTA36 pass was removed after it emitted malformed
   native alignments at Kki. Both repeat orientations are still queried in the regular direction,
   and malformed output continues to fail explicitly.
4. Complete mode independently scans genomic sequence for strong covariance-model hits. Hits
   with E-value ≤`1e-5` can be retained even when no anti-repeat candidate was generated. They
   have explicit `candidate_origin="covariance_model"` and
   `boundary_kind="model_supported_region"`, with absent anti-repeat/array/interaction/terminator
   evidence represented as null. An existing same-strand candidate or accepted array prevents
   duplicate/overlapping rescue in the defined cases.

With an unchanged 70% identity and 60% repeat-coverage threshold, these changes improved
localization from 45/78 to 68/78 exactly mapped references and execution from 54/79 to 79/79
inputs. Top-1 localization is 53/78. These references overlap the training-source collection;
the result establishes a regression improvement, not independent generalization or precision.
Ten mapped references remain missed, and model-supported regions do not establish full
transcript boundaries. The four bundled Type V models have demonstrated Type V-K coverage;
none recognized the 14 assessed Cas12f components.

## Highest-value next scientific work

1. **Independent biological validation.** Extend the sourced inventory with experimentally
   supported native transcripts and exhaustively annotated negative regions. Partition by
   species/clade and model-training provenance, and predeclare coordinate matching rules before
   assessing a held-out collection. The current positive-only regression set cannot estimate
   genome-wide precision. Later publication dates alone do not exclude homologous training data.
2. **Calibrate ranking.** The current score is an interpretable heuristic. Estimate feature
   scaling and operating thresholds on held-out data. Test whether correlated identity,
   coverage, and identity × coverage features are overweighted. Stratify Type II and Type V.
3. **Resolve transcript boundaries.** Current complete-mode intervals are anti-repeat search
   windows or model-supported regions. RNA-seq/TSS evidence, independent terminator validation
   and structural support can distinguish full transcripts from mature processed tracrRNAs.
   Neither the 150-base extension nor the covariance-model span is a validated endpoint.
4. **Circular replicons.** V3 clips at contig boundaries. Circular wrapping needs explicit
   topology metadata and split-interval output, with source reconstruction tests, before use.
5. **Candidate consolidation.** Keep raw hypotheses and add a separately defined locus layer
   that groups overlapping predictions across repeat orientations and models. Avoid discarding
   informative alternatives before validating a clustering rule.
6. **Search sensitivity comparisons.** FASTA36 remains the default; BLAST is optional. Compare
   their short anti-repeat sensitivity and hard-negative behavior with predeclared thresholds.
   Explore local Cas/array windows as an optional speed setting only after measuring recall loss.
7. **Broader RNA-family models.** Recover missing primary sequence tables and curate additional
   subtype-specific native references before training new covariance models. Use separate
   training, threshold-selection and test partitions. Extending Type V-K coverage to Cas12f or
   other Cas12 architectures is a model-development task, not a change of subtype label.

## Highest-value scaling work

Batch IntaRNA interactions when the supported CLI contract permits it. Cache upstream outputs
using full input, model and configuration hashes; implement checkpoint validation before resume.
For large cohorts, schedule independent records with an explicit global CPU/memory budget.
Current execution is sequential across records and bounded by the configured tool thread count.
Stream completed records into final exports for very large result sets instead of retaining all
prediction objects until completion. These are future improvements, not implemented guarantees.

## Scope and scientific sources

The preserved baseline is [CRISPRtracrRNA 2.0](https://github.com/BackofenLab/CRISPRtracrRNA/releases/tag/2.0).
The original [CRISPRtracrRNA publication](https://academic.oup.com/bioinformatics/article/38/Supplement_2/ii42/6702007)
describes the combined evidence approach. The supplied model families and their training
provenance should be checked against that work and the
[Type V-K V2 study](https://pmc.ncbi.nlm.nih.gov/articles/PMC12416283/) before any new performance claim.
Dependency classifications likewise retain the uncertainty and limitations documented by each
upstream tool. No change here turns classifier scores into biological probabilities.
