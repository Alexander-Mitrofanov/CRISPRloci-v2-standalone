"""Sequence, covariance-model, interaction, and terminator tool adapters."""

from __future__ import annotations

import csv
import math
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, cast

from .config import Settings
from .errors import ContractError
from .models import AntiRepeat, Array, Candidate, Hit, Interval, Sequence, Strand
from .process import Runner
from .sequence import reverse_complement, subsequence, write_fasta


def finite(value: str) -> float:
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("Non-finite scientific result")
    return number


def parse_cm_table(path: Path, lengths: dict[str, int], model: str) -> list[Hit]:
    """Parse Infernal 1.x cmscan --fmt 1; seqfrom/seqto encode strand direction."""
    hits = []
    try:
        for line in path.read_text().splitlines():
            if not line.strip() or line.startswith("#"):
                continue
            cols = line.split(maxsplit=17)
            if len(cols) < 17:
                raise ValueError("Truncated cmscan table row")
            query, strand = cols[2], cols[9]
            start, end = int(cols[7]), int(cols[8])
            if strand not in {"+", "-"} or query not in lengths:
                raise ValueError(f"Unknown cmscan sequence or strand: {query}, {strand}")
            interval = Interval.from_public(min(start, end), max(start, end))
            if interval.end > lengths[query]:
                raise ValueError("cmscan hit exceeds sequence")
            evalue = finite(cols[15])
            if evalue < 0:
                raise ValueError("Negative E-value")
            hits.append(
                Hit(
                    query,
                    interval,
                    cast(Strand, strand),
                    finite(cols[14]),
                    evalue,
                    model + ":" + cols[0],
                )
            )
    except (OSError, IndexError, ValueError) as exc:
        raise ContractError(f"Invalid Infernal table {path}: {exc}") from exc
    return hits


def scan_models(
    records: list[Sequence], work: Path, settings: Settings, runner: Runner
) -> list[Hit]:
    if not records:
        return []
    fasta = work / "cm-input.fasta"
    write_fasta(fasta, records)
    lengths = {r.id: len(r.bases) for r in records}
    hits = []
    for index, model in enumerate(settings.model_paths()):
        table = work / f"cm-{index}.tbl"
        runner.run(
            [
                settings.cmscan,
                "--cpu",
                str(settings.threads),
                "--noali",
                "--fmt",
                "1",
                "--tblout",
                str(table),
                str(model),
                str(fasta),
            ]
        )
        hits.extend(parse_cm_table(table, lengths, model.name))
    return hits


def parse_alignment_table(
    path: Path,
    queries: dict[str, tuple[Array, str, Strand]],
    source: Sequence,
    arrays: list[Array],
    settings: Settings,
    genome_is_query: bool = False,
) -> list[AntiRepeat]:
    results = []
    try:
        for line in path.read_text().splitlines():
            if not line.strip() or line.startswith("#"):
                continue
            cols = line.split()
            if len(cols) != 12:
                raise ValueError("Expected 12-column BLAST-format alignment")
            qid, sid = cols[0:2]
            qstart, qend, sstart, send = map(int, cols[6:10])
            if genome_is_query:
                qid, sid = sid, qid
                qstart, qend, sstart, send = sstart, send, qstart, qend
            if qid not in queries or sid != source.id:
                raise ValueError("Unknown sequence in alignment")
            array, repeat, repeat_strand = queries[qid]
            interval = Interval.from_public(min(sstart, send), max(sstart, send))
            q_interval = Interval.from_public(min(qstart, qend), max(qstart, qend))
            if interval.end > len(source.bases) or q_interval.end > len(repeat):
                raise ValueError("Alignment exceeds sequence length")
            # Query span, not gapped alignment length, keeps coverage within [0, 1].
            coverage = q_interval.length / len(repeat)
            identity = finite(cols[2]) / 100
            if not 0 <= identity <= 1:
                raise ValueError("Invalid alignment identity")
            if coverage < settings.coverage or identity < settings.similarity:
                continue
            if any(interval.overlap(a.interval) for a in arrays):
                continue
            relative_forward = (qend - qstart) * (send - sstart) >= 0
            complementary: Strand = "-" if relative_forward else "+"
            for strand in (complementary, "+" if complementary == "-" else "-"):
                results.append(
                    AntiRepeat(
                        array,
                        repeat,
                        repeat_strand,
                        interval,
                        strand,
                        identity,
                        coverage,
                        strand == complementary,
                    )
                )
    except (OSError, ValueError, KeyError) as exc:
        raise ContractError(f"Invalid anti-repeat alignment table {path}: {exc}") from exc
    return results


def search_anti_repeats(
    source: Sequence,
    fasta: Path,
    arrays: list[Array],
    work: Path,
    settings: Settings,
    runner: Runner,
) -> list[AntiRepeat]:
    if not arrays:
        return []
    search_fasta = fasta
    if settings.mask_arrays:
        # Perfect repeat copies inside arrays otherwise dominate FASTA36's
        # secondary-hit search. Post-filtering those alignments is too late:
        # valid, weaker anti-repeats may never have been reported.
        bases = list(source.bases)
        for array in arrays:
            bases[array.interval.start : array.interval.end] = "N" * array.interval.length
        search_fasta = work / "anti-search.fasta"
        write_fasta(search_fasta, [Sequence(source.id, source.description, "".join(bases))])
    queries: dict[str, tuple[Array, str, Strand]] = {}
    for index, array in enumerate(arrays):
        for strand in ("+", "-"):
            repeat = array.repeat if strand == "+" else reverse_complement(array.repeat)
            queries[f"repeat{index:06d}{'f' if strand == '+' else 'r'}"] = (array, repeat, strand)
    repeats = work / "repeats.fasta"
    write_fasta(repeats, [Sequence(k, k, v[1]) for k, v in queries.items()])
    output = work / "anti-repeat.tsv"
    if settings.search_backend == "blastn":
        runner.run(
            [
                settings.blastn,
                "-task",
                "blastn-short",
                "-query",
                str(repeats),
                "-subject",
                str(search_fasta),
                "-strand",
                "both",
                "-dust",
                "no",
                "-soft_masking",
                "false",
                "-evalue",
                "100",
                "-outfmt",
                "6",
                "-out",
                str(output),
            ]
        )
    else:
        # FASTA36's legacy library-name parser has a fixed-size path buffer.
        # Absolute paths of 120 characters can be corrupted (".fastax").
        # Our per-record directory already owns both inputs, so use short names.
        runner.run(
            [
                settings.fasta36,
                "-T",
                str(settings.threads),
                "-m",
                "8",
                repeats.name,
                search_fasta.name,
            ],
            cwd=work,
            stdout=output,
        )
    hits = parse_alignment_table(output, queries, source, arrays, settings)
    # Both repeat orientations are already searched. The old additional pass
    # with an entire genome as the FASTA36 query is redundant for strand coverage
    # and triggers native band-alignment corruption on some real loci (Kki).
    # Keep the short repeat as query; malformed output still fails closed.
    unique: dict[tuple[str, int, int, str, str], AntiRepeat] = {}
    for hit in hits:
        key = (hit.array.id, hit.interval.start, hit.interval.end, hit.repeat_strand, hit.strand)
        incumbent = unique.get(key)
        if incumbent is None or (hit.identity * hit.coverage, hit.identity) > (
            incumbent.identity * incumbent.coverage,
            incumbent.identity,
        ):
            unique[key] = hit
    return [unique[k] for k in sorted(unique)]


def make_candidates(
    source: Sequence, anti_repeats: list[AntiRepeat], settings: Settings
) -> list[Candidate]:
    results = []
    for index, anti in enumerate(anti_repeats):
        if anti.strand == "+":
            interval = Interval(
                max(0, anti.interval.start - settings.upstream_length),
                min(len(source.bases), anti.interval.end + settings.tail_length),
            )
            local = Interval(
                anti.interval.start - interval.start, anti.interval.end - interval.start
            )
        else:
            interval = Interval(
                max(0, anti.interval.start - settings.tail_length),
                min(len(source.bases), anti.interval.end + settings.upstream_length),
            )
            local = Interval(interval.end - anti.interval.end, interval.end - anti.interval.start)
        results.append(
            Candidate(
                f"candidate{index:06d}",
                anti,
                interval,
                subsequence(source.bases, interval, anti.strand),
                local,
            )
        )
    return results


def parse_erpin(path: Path, lengths: dict[str, int]) -> dict[str, list[Hit]]:
    results: dict[str, list[Hit]] = defaultdict(list)
    query = None
    try:
        for line in path.read_text().splitlines():
            if line.startswith(">"):
                query = line[1:].split()[0]
                if query not in lengths:
                    raise ValueError(f"Unknown ERPIN sequence {query}")
            elif re.match(r"^(FW|RC)\s", line):
                if query is None:
                    raise ValueError("ERPIN hit before sequence header")
                cols = line.split()
                start, end = map(int, cols[2].split(".."))
                interval = Interval.from_public(min(start, end), max(start, end))
                if interval.end > lengths[query]:
                    raise ValueError("ERPIN hit exceeds sequence")
                score, evalue = finite(cols[3]), finite(cols[4])
                if evalue < 0:
                    raise ValueError("Negative ERPIN E-value")
                results[query].append(
                    Hit(
                        query, interval, "+" if cols[0] == "FW" else "-", score, evalue, "rho-indep"
                    )
                )
    except (OSError, ValueError, IndexError) as exc:
        raise ContractError(f"Invalid ERPIN output {path}: {exc}") from exc
    return dict(results)


def terminators(
    candidates: list[Candidate], work: Path, settings: Settings, runner: Runner
) -> dict[str, list[Hit]]:
    if not candidates:
        return {}
    fasta = work / "terminator-input.fasta"
    write_fasta(fasta, [Sequence(c.id, c.id, c.sequence) for c in candidates])
    output = work / "erpin.txt"
    runner.run(
        [
            settings.erpin,
            settings.erpin_model,
            str(fasta),
            "-1,4",
            "-add",
            "2",
            "4",
            "2",
            "-pcw",
            "3.0",
            "-cutoff",
            "100%",
        ],
        stdout=output,
    )
    return parse_erpin(output, {c.id: len(c.sequence) for c in candidates})


def parse_intarna(path: Path, target_length: int, query_length: int) -> dict[str, Any] | None:
    try:
        with path.open(newline="") as handle:
            reader = csv.DictReader(handle, delimiter=";")
            required = {"start1", "end1", "start2", "end2", "E", "hybridDP"}
            if not required <= set(reader.fieldnames or []):
                raise ValueError("Missing IntaRNA output columns")
            rows = list(reader)
        if not rows:
            return None
        row = min(rows, key=lambda r: finite(r["E"]))
        target = Interval.from_public(int(row["start1"]), int(row["end1"]))
        query = Interval.from_public(int(row["start2"]), int(row["end2"]))
        if target.end > target_length or query.end > query_length:
            raise ValueError("IntaRNA interaction exceeds sequence")
        return {
            "target_interval": target.public(),
            "repeat_interval": query.public(),
            "energy_kcal_mol": finite(row["E"]),
            "hybrid_dot_bracket": row["hybridDP"],
        }
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise ContractError(f"Invalid IntaRNA output {path}: {exc}") from exc


def interaction(
    candidate: Candidate, work: Path, settings: Settings, runner: Runner
) -> dict[str, Any] | None:
    output = work / f"{candidate.id}.intarna.csv"
    runner.run(
        [
            settings.intarna,
            "-t",
            candidate.sequence,
            "-q",
            candidate.anti.repeat,
            "--outMode",
            "C",
            "--outCsvCols",
            "start1,end1,start2,end2,E,hybridDP",
            "--out",
            str(output),
            "--threads",
            str(settings.threads),
        ]
    )
    return parse_intarna(output, len(candidate.sequence), len(candidate.anti.repeat))
