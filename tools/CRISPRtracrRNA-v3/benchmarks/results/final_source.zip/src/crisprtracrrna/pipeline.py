"""Explicit orchestration with isolated per-record working directories."""

from __future__ import annotations

import csv
import json
import logging
import os
import shutil
import subprocess
import time
from collections import defaultdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

from . import __version__
from .adapters import load_json, run_casandra, run_identify, sha256_file
from .config import DATA, Settings
from .errors import TracrError
from .evidence import candidate_evidence, merge_model_hits, model_rescue_predictions
from .models import Hit, Sequence
from .process import Runner
from .search import interaction, make_candidates, scan_models, search_anti_repeats, terminators
from .sequence import input_files, read_fasta, write_fasta

LOG = logging.getLogger(__name__)


def doctor(settings: Settings) -> dict[str, Any]:
    required = {"cmscan": settings.cmscan}
    if settings.mode == "complete":
        required.update(
            {
                "identify": settings.identify_command[0],
                "casandra": settings.casandra_command[0],
                "IntaRNA": settings.intarna,
                "erpin": settings.erpin,
                settings.search_backend: getattr(settings, settings.search_backend),
            }
        )
    search_path = settings.environment.get("PATH", os.environ.get("PATH"))
    executables = {name: shutil.which(value, path=search_path) for name, value in required.items()}
    missing = [
        f"executable: {name} ({required[name]})" for name, path in executables.items() if not path
    ]
    resources = list(settings.model_paths())
    for model in settings.model_paths():
        resources.extend(Path(str(model) + suffix) for suffix in (".i1f", ".i1i", ".i1m", ".i1p"))
    if settings.mode == "complete":
        resources.append(Path(settings.erpin_model))
    missing.extend(f"resource: {path}" for path in resources if not path.is_file())
    manifest = load_json(DATA / "manifest.json")
    for relative, expected in manifest.items():
        resource = DATA / relative
        if not resource.is_file() or sha256_file(resource) != expected:
            missing.append(f"Bundled resource checksum mismatch: {relative}")
    return {
        "ready": not missing,
        "executables": executables,
        "errors": missing,
        "note": (
            "Checks paths and bundled resources; upstream runtimes are verified during execution."
        ),
    }


def atomic_json(path: Path, value: Any) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def command_provenance(command: tuple[str, ...]) -> dict[str, Any]:
    """Record checkout revision when a command directly references a repository."""
    result: dict[str, Any] = {"command": command}
    for part in command:
        path = Path(part)
        if path.is_file():
            result.setdefault("files", {})[str(path.resolve())] = sha256_file(path)
            try:
                revision = subprocess.run(
                    ["git", "-C", str(path.resolve().parent), "rev-parse", "HEAD"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                    check=False,
                )
                if revision.returncode == 0:
                    result["git_commit"] = revision.stdout.strip()
            except (OSError, subprocess.TimeoutExpired):
                pass
    return result


def analyze_record(source: Sequence, work: Path, settings: Settings) -> dict[str, Any]:
    work.mkdir()
    fasta = work / "input.fasta"
    write_fasta(fasta, [source])
    runner = Runner(work / "logs", settings.timeout, settings.environment)
    if settings.mode == "model":
        LOG.info("Searching covariance models in %s (%s nt)", source.id, len(source.bases))
        hits = scan_models([source], work, settings, runner)
        return {
            "predictions": merge_model_hits(
                source, hits, settings.merge_gap, settings.type_v_motifs
            ),
            "raw_model_hits": [h.public() for h in hits],
            "arrays": [],
            "cas": {"status": "not_requested"},
        }
    LOG.info("Running CRISPRidentify for %s", source.id)
    arrays, identify_report = run_identify(fasta, source, work, settings, runner)
    LOG.info("Running standalone CasAndra for %s", source.id)
    cas = run_casandra(fasta, source, work, settings, runner)
    LOG.info("Searching anti-repeats for %s (%s accepted arrays)", source.id, len(arrays))
    anti = search_anti_repeats(source, fasta, arrays, work, settings, runner)
    candidates = make_candidates(source, anti, settings)
    LOG.info("Scoring %s transcript hypotheses for %s", len(candidates), source.id)
    cm_hits = scan_models(
        [Sequence(c.id, c.id, c.sequence) for c in candidates], work, settings, runner
    )
    by_query: dict[str, list[Hit]] = defaultdict(list)
    for hit in cm_hits:
        by_query[hit.query].append(hit)
    terms = terminators(candidates, work, settings, runner)
    predictions = []
    for candidate in candidates:
        rna_interaction = interaction(candidate, work, settings, runner)
        predictions.append(
            candidate_evidence(
                candidate,
                source,
                by_query[candidate.id],
                terms.get(candidate.id, []),
                rna_interaction,
                cas,
                settings,
            )
        )
    genome_hits = []
    if settings.model_rescue:
        # Scan the genome independently: scanning only anti-repeat windows makes
        # complete mode blind to strong CM loci missed by the sequence branch.
        model_work = work / "genomic-models"
        model_work.mkdir()
        genome_hits = scan_models([source], model_work, settings, runner)
        predictions.extend(
            model_rescue_predictions(source, genome_hits, arrays, predictions, cas, settings)
        )
    predictions.sort(key=lambda p: (-p["ranking"]["score"], p["id"]))
    return {
        "predictions": predictions,
        "raw_genomic_model_hits": [h.public() for h in genome_hits],
        "arrays": [
            a["id"] for a in identify_report["arrays"] if a["category"] in {"Bona-fide", "Possible"}
        ],
        "identify": {"schema": identify_report["schema"], "run": identify_report["run"]},
        "cas": {
            "status": cas["status"],
            "run": cas["run"],
            "cas_gene_count": sum(g["prediction"]["is_cas"] for g in cas["genes"]),
            "cassettes": cas["cassettes"],
        },
    }


def write_exports(output: Path, records: list[dict[str, Any]]) -> None:
    fields = [
        "source_file",
        "sequence_id",
        "prediction_id",
        "candidate_origin",
        "boundary_kind",
        "start",
        "end",
        "strand",
        "sequence",
        "score",
        "evalue",
        "array_id",
        "array_category",
        "anti_repeat_identity",
        "anti_repeat_coverage",
        "interaction_energy_kcal_mol",
        "model_score",
        "terminator_evalue",
        "cas_cassette_id",
        "cas_distance_bases",
    ]
    with (
        (output / "summary.csv").open("w", newline="", encoding="utf-8") as handle,
        (output / "predictions.fasta").open("w", encoding="utf-8") as fasta,
        (output / "predictions.gff3").open("w", encoding="utf-8") as gff,
    ):
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        gff.write("##gff-version 3\n")
        for record in records:
            source = record["source"]
            # Prefix with record key to avoid collisions across files with reused contig IDs.
            seqid = quote(record["key"] + ":" + source["id"], safe="._:-")
            gff.write(f"##sequence-region {seqid} 1 {source['length']}\n")
            for ordinal, prediction in enumerate(record["predictions"], 1):
                identity = f"{record['key']}.p{ordinal:06d}"
                prediction["export_id"] = identity
                interval = prediction["interval"]
                ranking = prediction.get("ranking", {})
                interaction_row = prediction.get("interaction") or {}
                model = prediction.get("model_hit") or {}
                term = prediction.get("terminator") or {}
                cas = prediction.get("cas_context") or {}
                anti = prediction.get("anti_repeat") or {}
                array = prediction.get("array") or {}
                writer.writerow(
                    {
                        "source_file": source["file"],
                        "sequence_id": source["id"],
                        "prediction_id": identity,
                        "candidate_origin": prediction.get("candidate_origin", "covariance_model"),
                        "boundary_kind": prediction.get("boundary_kind", "merged_model_region"),
                        "start": interval["start"],
                        "end": interval["end"],
                        "strand": prediction["strand"],
                        "sequence": prediction["sequence"],
                        "score": ranking.get("score", prediction.get("best_score")),
                        "evalue": prediction.get("best_evalue"),
                        "array_id": array.get("id"),
                        "array_category": array.get("category"),
                        "anti_repeat_identity": anti.get("identity"),
                        "anti_repeat_coverage": anti.get("coverage"),
                        "interaction_energy_kcal_mol": interaction_row.get("energy_kcal_mol"),
                        "model_score": model.get("score"),
                        "terminator_evalue": term.get("evalue"),
                        "cas_cassette_id": cas.get("id"),
                        "cas_distance_bases": cas.get("distance_bases"),
                    }
                )
                fasta.write(
                    f">{identity} source={quote(source['id'], safe='._-')} "
                    f"start={interval['start']} end={interval['end']} "
                    f"strand={prediction['strand']}\n"
                    f"{prediction['sequence']}\n"
                )
                gff.write(
                    f"{seqid}\tCRISPRtracrRNA\tncRNA\t{interval['start']}\t{interval['end']}\t.\t"
                    f"{prediction['strand']}\t.\tID={identity};inference=ab%20initio%20prediction;"
                    "product=tracrRNA%20candidate\n"
                )


def run(input_path: Path, output: Path, settings: Settings) -> dict[str, Any]:
    files = input_files(input_path)
    readiness = doctor(settings)
    if not readiness["ready"]:
        raise TracrError("Preflight failed:\n" + "\n".join(readiness["errors"]))
    output = output.resolve()
    if output.exists():
        raise TracrError(f"Refusing to overwrite existing output: {output}")
    output.mkdir(parents=True)
    work = output / "work"
    work.mkdir()
    started = time.monotonic()
    records: list[dict[str, Any]] = []
    config = settings.public()
    atomic_json(output / "configuration.json", config)
    try:
        for file_index, path in enumerate(files, 1):
            input_digest = sha256_file(path)
            for sequence_index, original in enumerate(read_fasta(path), 1):
                key = f"f{file_index:06d}.s{sequence_index:06d}"
                # Tools receive safe opaque IDs; the original ID and header are retained.
                source = Sequence(key, key, original.bases)
                result = analyze_record(source, work / key, settings)
                record = {
                    "key": key,
                    "source": {
                        "file": str(path),
                        "file_sha256": input_digest,
                        "id": original.id,
                        "header": original.description,
                        "length": len(source.bases),
                        "sha256": source.sha256,
                        "normalization": "uppercase; U converted to T",
                    },
                    **result,
                }
                records.append(record)
                atomic_json(work / key / "record.json", record)
        write_exports(output, records)
        report = {
            "schema": {"name": "CRISPRtracrRNA-report", "version": "3.0.0"},
            "program_version": __version__,
            "status": "complete",
            "created_at": datetime.now(UTC).isoformat(),
            "wall_seconds": round(time.monotonic() - started, 6),
            "coordinate_system": {
                "indexing": 1,
                "end_inclusive": True,
                "reference": "input_forward_strand",
                "strand_is_separate": True,
            },
            "local_coordinate_reference": "oriented_prediction_sequence",
            "configuration": config,
            "tool_provenance": {
                "identify": command_provenance(settings.identify_command),
                "casandra": command_provenance(settings.casandra_command),
            },
            "model_sha256": {str(p): sha256_file(p) for p in settings.model_paths()},
            "summary": {
                "sequence_count": len(records),
                "prediction_count": sum(len(r["predictions"]) for r in records),
            },
            "records": records,
        }
        # Hash all retained evidence before publishing the completion marker last.
        manifest = {
            str(p.relative_to(output)): sha256_file(p)
            for p in sorted(output.rglob("*"))
            if p.is_file()
        }
        atomic_json(output / "manifest.json", {"algorithm": "sha256", "files": manifest})
        atomic_json(output / "report.json", report)
        return report
    except BaseException as exc:
        atomic_json(
            output / "failure.json",
            {"status": "failed", "error": str(exc), "completed_sequences": len(records)},
        )
        raise
