"""Logged, shell-free commands with process-group cancellation."""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time
from pathlib import Path

from .errors import ToolError


class Runner:
    def __init__(
        self, directory: Path, timeout: float = 3600, environment: dict[str, str] | None = None
    ) -> None:
        self.directory = directory.resolve()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.timeout = timeout
        self.environment = {**os.environ, **(environment or {}), "PYTHONDONTWRITEBYTECODE": "1"}
        self.records: list[dict[str, object]] = []
        self._digests: dict[str, str] = {}

    def run(
        self,
        command: list[str],
        *,
        cwd: Path | None = None,
        stdout: Path | None = None,
        environment: dict[str, str] | None = None,
    ) -> Path:
        ordinal = len(self.records) + 1
        output = stdout or self.directory / f"{ordinal:04d}.stdout.log"
        error = self.directory / f"{ordinal:04d}.stderr.log"
        env = {**self.environment, **(environment or {})}
        executable = shutil.which(command[0], path=env.get("PATH"))
        if not executable:
            raise ToolError(f"Executable not found: {command[0]}")
        command = [executable, *command[1:]]
        if executable not in self._digests:
            with Path(executable).open("rb") as handle:
                self._digests[executable] = hashlib.file_digest(handle, "sha256").hexdigest()
        record: dict[str, object] = {
            "argv": command,
            "executable_sha256": self._digests[executable],
            "cwd": str(cwd or self.directory),
            "stdout": str(output),
            "stderr": str(error),
            "timeout_seconds": self.timeout,
        }
        self.records.append(record)
        started = time.monotonic()
        try:
            with output.open("wb") as out, error.open("wb") as err:
                proc = subprocess.Popen(
                    command,
                    cwd=cwd or self.directory,
                    env=env,
                    stdout=out,
                    stderr=err,
                    start_new_session=True,
                )
                try:
                    code = proc.wait(timeout=self.timeout)
                except BaseException:
                    # Reap descendants as well as the launcher; never leave inference running.
                    with contextlib.suppress(ProcessLookupError):
                        os.killpg(proc.pid, signal.SIGTERM)
                    with contextlib.suppress(subprocess.TimeoutExpired):
                        proc.wait(timeout=2)
                    with contextlib.suppress(ProcessLookupError):
                        os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                    raise
                record["returncode"] = code
                if code:
                    tail = error.read_text(errors="replace")[-3000:]
                    raise ToolError(f"{command[0]} exited {code}. See {error}\n{tail}")
        except subprocess.TimeoutExpired as exc:
            record["timed_out"] = True
            raise ToolError(f"{command[0]} timed out after {self.timeout}s; see {error}") from exc
        except OSError as exc:
            raise ToolError(f"Cannot execute {command[0]}: {exc}") from exc
        finally:
            record["seconds"] = round(time.monotonic() - started, 6)
            (self.directory / "commands.json").write_text(
                json.dumps(self.records, indent=2) + "\n", encoding="utf-8"
            )
        return output
