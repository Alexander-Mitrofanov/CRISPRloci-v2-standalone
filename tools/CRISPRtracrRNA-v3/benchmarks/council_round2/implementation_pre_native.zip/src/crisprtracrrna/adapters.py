"""Versioned file contracts for unmodified CRISPRidentify v2 and CasAndra."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, cast

from .config import Settings
from .errors import ContractError
from .models import Array, Interval, Sequence
from .process import Runner
from .sequence import normalize


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    def invalid_constant(value: str) -> None:
        raise ValueError(f"Non-finite JSON number {value}")

    try:
        data = json.loads(path.read_text(encoding="utf-8"), parse_constant=invalid_constant)
        if not isinstance(data, dict):
            raise ValueError("Expected JSON object")
        return cast(dict[str, Any], data)
    except (OSError, ValueError) as exc:
        raise ContractError(f"Cannot read structured report {path}: {exc}") from exc


def parse_identify(path: Path, source: Sequence) -> tuple[list[Array], dict[str, Any]]:
    report = load_json(path)
    try:
        schema = report["schema"]
        if schema["name"] != "CRISPRidentify-report" or schema["version"].split(".")[0] != "1":
            raise ValueError(f"Unsupported CRISPRidentify schema {schema}")
        coords = report["coordinate_system"]
        if (
            coords["indexing"] != 1
            or coords["end_inclusive"] is not True
            or coords["reference"] != "input_forward_strand"
        ):
            raise ValueError("Unsupported CRISPRidentify coordinates")
        reported_source = report["source"]
        if (
            reported_source["sha256"] != source.sha256
            or reported_source["id"] != source.id
            or reported_source["length"] != len(source.bases)
        ):
            raise ValueError("CRISPRidentify source identity/hash does not match the input")
        if report["validation"]["status"] != "valid":
            raise ValueError("CRISPRidentify reports invalid source reconstruction")
        arrays = []
        seen = set()
        for row in report["arrays"]:
            if row["category"] not in {"Bona-fide", "Possible"}:
                continue
            interval = Interval.from_public(
                row["source_interval"]["start"], row["source_interval"]["end"]
            )
            if interval.end > len(source.bases):
                raise ValueError("Array exceeds contig boundary")
            if row["validation"]["status"] != "valid":
                raise ValueError("Invalid array reconstruction")
            if (
                row.get("source_sequence", source.bases[interval.start : interval.end])
                != source.bases[interval.start : interval.end]
            ):
                raise ValueError("Array sequence does not reconstruct from source")
            strand = row["orientation"].get("strand")
            if strand not in {"+", "-", None}:
                raise ValueError(f"Invalid array orientation {strand}")
            score = float(row["certainty_score"])
            if not math.isfinite(score) or not 0 <= score <= 1:
                raise ValueError("Invalid array score")
            if row["id"] in seen:
                raise ValueError("Duplicate array id")
            seen.add(row["id"])
            arrays.append(
                Array(
                    row["id"],
                    interval,
                    normalize(row["consensus_repeat"]),
                    strand,
                    row["category"],
                    score,
                )
            )
        return arrays, report
    except (KeyError, TypeError, ValueError, AttributeError) as exc:
        raise ContractError(f"Incompatible CRISPRidentify report {path}: {exc}") from exc


def run_identify(
    fasta: Path, source: Sequence, work: Path, settings: Settings, runner: Runner
) -> tuple[list[Array], dict[str, Any]]:
    output = work / "identify"
    runner.run(
        [
            *settings.identify_command,
            "--file",
            str(fasta),
            "--result_folder",
            str(output),
            "--preset",
            settings.identify_preset,
            "--cas",
            "False",
            "--cpu",
            str(settings.threads),
        ]
    )
    reports = sorted(output.rglob("report.json"))
    if len(reports) != 1:
        raise ContractError(f"Expected one CRISPRidentify report, got {len(reports)} in {output}")
    return parse_identify(reports[0], source)


def parse_casandra(directory: Path, fasta: Path, source: Sequence) -> dict[str, Any]:
    run = load_json(directory / "run.json")
    manifest = load_json(directory / "manifest.json")
    try:
        if (
            run["program"] != "CasAndra"
            or run["schema_version"] != 5
            or manifest["schema_version"] != 5
        ):
            raise ValueError("Unsupported CasAndra genome report schema (expected 5)")
        if not any(
            row["sha256"] == sha256_file(fasta) and row["kind"] == "genome_fasta"
            for row in run["inputs"]
        ):
            raise ValueError("CasAndra input digest does not match")
        result: dict[str, Any] = {"run": run, "status": "computed"}
        for filename, key in (("proteins.jsonl", "genes"), ("cassettes.jsonl", "cassettes")):
            path = directory / filename
            if sha256_file(path) != manifest["files"][filename]["sha256"]:
                raise ValueError(f"CasAndra checksum mismatch: {filename}")
            rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
            for row in rows:
                interval = Interval.from_public(row["start_1based"], row["end_1based_inclusive"])
                if interval.end > len(source.bases) or row["contig_id"] != source.id:
                    raise ValueError("CasAndra coordinates or contig do not match the source")
                if key == "genes":
                    if type(row["prediction"]["is_cas"]) is not bool:
                        raise ValueError("CasAndra is_cas must be a boolean")
                elif not isinstance(row["final_classification"], dict):
                    raise ValueError("Missing CasAndra cassette classification")
            result[key] = rows
        if len(result["genes"]) != run["genes"] or len(result["cassettes"]) != run["cas_cassettes"]:
            raise ValueError("CasAndra record count mismatch")
        return result
    except (OSError, KeyError, TypeError, ValueError) as exc:
        raise ContractError(f"Incompatible CasAndra output in {directory}: {exc}") from exc


def run_casandra(
    fasta: Path, source: Sequence, work: Path, settings: Settings, runner: Runner
) -> dict[str, Any]:
    output = work / "casandra"
    runner.run(
        [
            *settings.casandra_command,
            "predict-genome",
            "--genome",
            str(fasta),
            "--output",
            str(output),
            "--threads",
            str(settings.threads),
            "--gene-mode",
            settings.gene_mode,
        ]
    )
    return parse_casandra(output, fasta, source)


def nearest_cas(interval: Interval, cas: dict[str, Any], model_type: str) -> dict[str, Any] | None:
    rows = [
        row for row in cas["cassettes"] if row["final_classification"].get("type") == model_type
    ]
    if not rows:
        return None
    row = min(
        rows,
        key=lambda r: (
            interval.distance(Interval.from_public(r["start_1based"], r["end_1based_inclusive"])),
            r["cassette_id"],
        ),
    )
    location = Interval.from_public(row["start_1based"], row["end_1based_inclusive"])
    return {
        "id": row["cassette_id"],
        "interval": location.public(),
        "distance_bases": interval.distance(location),
        "classification": row["final_classification"],
    }
