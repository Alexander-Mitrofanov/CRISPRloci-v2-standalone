#!/usr/bin/env python3
"""Fetch pinned upstream repositories or advance one clean checkout explicitly.

No upstream source is patched. Updating a dependency requires re-running the
integration tests and its documented installation/build steps before production.
"""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAMES = ("CRISPRidentify-v2", "CasAndra")


def git(*args: str, cwd: Path | None = None) -> str:
    return subprocess.check_output(["git", *args], cwd=cwd, text=True).strip()


def sync(name: str, entry: dict[str, str]) -> None:
    destination = ROOT / "external" / name
    if destination.exists():
        if git("status", "--porcelain", "--untracked-files=no", cwd=destination):
            raise RuntimeError(f"Refusing to alter modified upstream checkout: {destination}")
        current = git("rev-parse", "HEAD", cwd=destination)
        if current == entry["commit"]:
            print(f"{name}: already at {current}")
            return
        raise RuntimeError(
            f"{name} is at {current}, not locked {entry['commit']}; "
            "preserve that checkout elsewhere before syncing"
        )
    destination.parent.mkdir(parents=True, exist_ok=True)
    git("clone", "--no-checkout", "--filter=blob:none", entry["url"], str(destination))
    git("checkout", "--detach", entry["commit"], cwd=destination)
    print(f"{name}: {git('rev-parse', 'HEAD', cwd=destination)}")


def update(name: str, ref: str, lock: dict[str, dict[str, str]]) -> None:
    if ref.startswith("-"):
        raise ValueError("A Git ref cannot begin with '-'")
    destination = ROOT / "external" / name
    if git("status", "--porcelain", cwd=destination):
        raise RuntimeError(f"Refusing update: {destination} has local changes")
    if git("remote", "get-url", "origin", cwd=destination) != lock[name]["url"]:
        raise RuntimeError("Repository remote does not match the dependency lock")
    old = git("rev-parse", "HEAD", cwd=destination)
    if old != lock[name]["commit"]:
        raise RuntimeError(
            "Current checkout differs from lock; resolve the mismatch before updating"
        )
    git("fetch", "origin", ref, cwd=destination)
    new = git("rev-parse", "FETCH_HEAD", cwd=destination)
    git("checkout", "--detach", new, cwd=destination)
    lock[name]["commit"] = new
    lock[name]["previous_commit"] = old
    lock[name]["requested_ref"] = ref
    temporary = ROOT / "upstream-lock.json.tmp"
    temporary.write_text(json.dumps(lock, indent=2) + "\n")
    temporary.replace(ROOT / "upstream-lock.json")
    print(f"{name}: {old} -> {new}")
    print(
        "Reinstall/rebuild this upstream using its instructions, "
        "then run the real integration tests."
    )
    print("This command records a candidate dependency update; it does not certify compatibility.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("sync", help="Download the exact versions in upstream-lock.json")
    change = commands.add_parser("update", help="Explicitly update one unmodified upstream")
    change.add_argument("name", choices=NAMES)
    change.add_argument("--ref", required=True, help="Git tag, branch, or commit")
    args = parser.parse_args()
    lock = json.loads((ROOT / "upstream-lock.json").read_text())
    if args.command == "sync":
        for name in NAMES:
            sync(name, lock[name])
    else:
        update(args.name, args.ref, lock)


if __name__ == "__main__":
    main()
