"""Control generators must preserve exact invariants and per-item stability."""

import importlib.util
import random
import sys
from collections import Counter
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
spec = importlib.util.spec_from_file_location("council_benchmark", SCRIPTS / "council_benchmark.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_exact_dinucleotide_and_ambiguity_invariants():
    for sequence in ("", "A", "AAAA", "ACGNTACRGT", "AACCGGTTACGTGACTAGCTAGCTGATCGATCGGAT"):
        for value in range(30):
            shuffled = module.dinucleotide_shuffle(sequence, random.Random(value))
            assert len(shuffled) == len(sequence)
            assert Counter(shuffled) == Counter(sequence)
            assert Counter(zip(shuffled, shuffled[1:], strict=False)) == Counter(
                zip(sequence, sequence[1:], strict=False)
            )
            assert all(shuffled[i] == base for i, base in enumerate(sequence) if base not in "ACGT")


def test_order_independent_seed_and_mono_invariants():
    sequences = {"a": "ACGT" * 15, "b": "AGCTTAGCRNNACGT" * 4}

    def generate(items):
        return {
            key: module.dinucleotide_shuffle(value, random.Random(module.seed(key, "test", 1)))
            for key, value in items
        }

    assert generate(sequences.items()) == generate(reversed(list(sequences.items())))
    assert generate(sequences.items()) == {
        key: value
        for key, value in generate([("new", "AGCT"), *sequences.items()]).items()
        if key != "new"
    }
    assert module.seed("a", "test", 1) != module.seed("a", "test", 2)
    source = "ACGTNRNACGT" * 3
    result = module.mono_shuffle(source, random.Random(10))
    assert Counter(result) == Counter(source)
    assert all(result[i] == base for i, base in enumerate(source) if base not in "ACGT")


def test_derangement_is_bijective_cross_locus_and_excludes_identical_and_rc():
    repeats = ["AACC", "ACGC", "ATAC", "CGGA", "GGTT", "AGCG"]
    pool = [
        {"identity": str(i), "label": str(i), "repeat": repeat} for i, repeat in enumerate(repeats)
    ]
    assignments = module.donor_assignment(pool)
    assert assignments == module.donor_assignment(pool[::-1])
    assert set(assignments) == set(assignments.values()) == {str(i) for i in range(len(pool))}
    for recipient, donor in assignments.items():
        assert recipient != donor
        assert repeats[int(donor)] not in {
            repeats[int(recipient)],
            module.reverse_complement(repeats[int(recipient)]),
        }
