"""Exercise the update workflow using local repositories, without network access."""

import importlib.util
import json
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "dependency_manager", ROOT / "scripts/dependencies.py"
)
dependencies = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dependencies)


def git(path, *args):
    return subprocess.check_output(["git", "-C", str(path), *args], text=True).strip()


def commit(path, text):
    (path / "runtime.py").write_text(text)
    git(path, "add", "runtime.py")
    git(path, "-c", "user.name=Test", "-c", "user.email=test@example.invalid", "commit", "-m", text)
    return git(path, "rev-parse", "HEAD")


def test_independent_update_preserves_unmodified_sources_and_lock(tmp_path, monkeypatch):
    upstream = tmp_path / "upstream"
    upstream.mkdir()
    git(upstream, "init", "-b", "main")
    first = commit(upstream, "v1")
    root = tmp_path / "project"
    root.mkdir()
    monkeypatch.setattr(dependencies, "ROOT", root)
    lock = {"CasAndra": {"url": str(upstream), "commit": first}}
    dependencies.sync("CasAndra", lock["CasAndra"])
    second = commit(upstream, "v2")
    dependencies.update("CasAndra", "main", lock)
    target = root / "external/CasAndra"
    assert git(target, "rev-parse", "HEAD") == second
    assert not git(target, "status", "--porcelain")
    saved = json.loads((root / "upstream-lock.json").read_text())
    assert saved["CasAndra"]["previous_commit"] == first
    assert saved["CasAndra"]["commit"] == second
    (target / "runtime.py").write_text("local modification")
    with pytest.raises(RuntimeError, match="local changes"):
        dependencies.update("CasAndra", "main", lock)
    assert (target / "runtime.py").read_text() == "local modification"
