# CRISPRtracrRNA v3

A refactored tracrRNA **candidate prediction** pipeline. It supports covariance-model screening
and complete analysis combining CRISPR arrays, anti-repeat similarity, RNA–RNA interaction,
terminators, structural models, and Cas-system context. Predictions and ranking scores are
research evidence, not calibrated probabilities or experimentally established tracrRNA genes.

The [literature inventory and benchmark](docs/LITERATURE_BENCHMARK.md) contains 304,447 source
records representing 42,712 distinct normalized sequences. Most are computational predictions;
the evidence category and original source are retained for every record. On 78 exactly mapped
published Type II reference loci, complete-mode localization improved from 45/78 to 68/78 after
the fixes described in that report. These references overlap the model-training collection and
measure regression performance, not independent generalization.
The inventory includes the recovered original Briner and Chyou supplements, with extraction
provenance and per-sequence model-recognition results.

The v2 release is preserved in `../old_version/`. V3 does not import v2 or depend on that folder.
The original Type II and four Type V covariance models and ERPIN resources are retained with
checksums. CRISPRidentify v2 and standalone CasAndra are independent, unmodified repositories;
they run through their public CLIs in their own environments.

## Installation

Supported scientific runtime: **Linux x86-64**, Python **3.11+**. The orchestration package uses
only Python's standard library. The bundled historical ERPIN executable is Linux x86-64;
other platforms need a compatible ERPIN executable and the other scientific tools.

```bash
cd new_version
conda env create -f environment.yml
conda activate crisprtracrrna-v3
python -m pip install -e '.[dev]'
python scripts/dependencies.py sync
```

Git access to both upstream repositories is required; they were private when this checkout
was prepared. Use your existing Git credentials. Dependency versions are frozen in
[`upstream-lock.json`](upstream-lock.json).

Install CRISPRidentify using its own installer:

```bash
cd external/CRISPRidentify-v2
./install.sh
cd ../..
```

Install standalone CasAndra in a separate environment:

```bash
python -m venv .envs/casandra
.envs/casandra/bin/python -m pip install ./external/CasAndra
```

Copy [`config.example.toml`](config.example.toml) to `config.toml` and set:

```toml
identify_command = ["external/CRISPRidentify-v2/crispridentify"]
casandra_command = [".envs/casandra/bin/casandra"]
```

CRISPRidentify's documented `CRISPRIDENTIFY_ENV` override can reuse an already installed
compatible environment. Its fresh checkout still needs its native matcher built with the
upstream build script and matching compiler. No upstream Python or C source is edited.

```bash
crisprtracrrna doctor --config config.toml
crisprtracrrna run --config config.toml --input examples/complete.fasta --output runs/complete
```

This workspace also contains an ignored `local.toml` that uses the installed scientific
runtimes on this machine. It is ready to run:

```bash
python CRISPRtracrRNA.py run --config local.toml \
  --input examples/complete.fasta --output runs/my-analysis
```

## Model-only and Type V searches

Model-only mode needs Infernal and the bundled models, but does not invoke CRISPRidentify,
CasAndra, FASTA36, IntaRNA, or ERPIN.
The four historical models selected by `--model-type V` cover **Type V-K tracrRNA families**.
This option does not provide general coverage of every Cas12 subtype. For example, none of
14 published Cas12f tracr components in the literature benchmark matched these models.

```bash
crisprtracrrna run --mode model --input genomes/ --output runs/model-II
crisprtracrrna run --mode model --model-type V --type-v-motifs \
  --input genomes.fasta.gz --output runs/model-V
```

Both modes accept one FASTA, multi-record FASTA, gzip FASTA, or a directory of FASTAs.
Each record is analyzed separately. IDs containing dots, spaces in file paths, and identical
contig IDs in different files are preserved without collision. Duplicate IDs within one FASTA
are rejected. All files must be valid; partial runs never publish a completion report.

## Results

- `report.json`: canonical versioned result, published only after successful completion.
- `summary.csv`: correctly quoted table, including a header for zero predictions.
- `predictions.fasta`, `predictions.gff3`: oriented sequences and forward-reference coordinates.
- `configuration.json`: effective settings and ranking weights.
- `manifest.json`: SHA-256 checksums for retained evidence and exports (the final report and
  manifest itself are excluded to avoid circular hashes).
- `work/`: isolated records, original upstream reports, raw tool outputs, command logs and timings.
- `failure.json`: explicit failed-run marker, with no top-level `report.json`.

Outputs never overwrite an existing directory. Use a fresh output path for a new run.
Coordinates are **1-based, end-inclusive on the original forward strand**, with strand separate.
Local evidence coordinates refer to the prediction sequence in its reported orientation.
FASTA/GFF identifiers include a run-local source key; `report.json` maps this key to the original
file, contig identifier, full header, and sequence digest.

Complete mode reports two explicit candidate origins:

- `anti_repeat`: a **search window** around an anti-repeat hypothesis, including up to 5 upstream
  and 150 downstream bases, labeled `boundary_kind="anti_repeat_search_window"`.
- `covariance_model`: a genomic model hit retained by the independent rescue search, labeled
  `boundary_kind="model_supported_region"`. Its array, anti-repeat, interaction and terminator
  fields are null when that evidence was not obtained.

Neither interval establishes a full transcript boundary. Both repeat orientations and both
transcript hypotheses are retained and labeled in the anti-repeat branch. Only accepted
CRISPRidentify arrays (Bona-fide and Possible) seed that branch; their intervals are masked in
the search copy so perfect repeat copies do not hide weaker external anti-repeats. The original
sequence and coordinates remain unchanged. CasAndra provides contextual annotation; absence
of a Cas cassette does not suppress the candidate search. Strong genomic model hits can be
reported even when the anti-repeat branch produces no candidate.

## Configuration and API

See the example TOML for thresholds, commands, timeouts, thread budget, and ranking weights.
Commands are argument arrays, never shell snippets. No analysis downloads dependencies.
FASTA36 remains the default anti-repeat search; `--search-backend blastn` selects an explicitly
recorded alternative (`blastn-short`, both strands, DUST and soft masking disabled). The separate
array masking step applies to either backend by default. These backends can return different
candidates. Models are searched with Infernal `cmscan --fmt 1` and its default reporting
threshold; custom models must have their four `cmpress` index files alongside them.

In complete mode, `model_rescue = true` adds an independent genomic model search and retains
hits with E-values at most `model_rescue_evalue` (default `1e-5`). Hits overlapping accepted arrays
or already contained in a same-strand candidate window are excluded from rescue. `mask_arrays = true`
enables the masking step. The CLI supports `--no-model-rescue`, `--model-rescue-evalue VALUE`,
and `--no-mask-arrays` for explicit comparisons. Anti-repeat defaults remain 70% identity and
60% repeat coverage. No models were retrained on the new benchmark.

```python
from pathlib import Path
from crisprtracrrna.config import load_settings
from crisprtracrrna.pipeline import run

settings = load_settings(Path("config.toml"), {"threads": 4})
report = run(Path("genome.fasta"), Path("runs/python-api"), settings)
```

Legacy `--input_folder`, `--output_folder`, `--run_type`, `--model_type`, similarity and coverage
flags, and `--perform_type_v_anti_repeat_analysis False` are supported by `CRISPRtracrRNA.py`.
V3 deliberately has a new output schema. See [migration and fixes](docs/MIGRATION.md),
[dependency updates](docs/DEPENDENCIES.md), [validation](docs/VALIDATION.md), and
[scientific improvements](docs/IMPROVEMENTS.md).

## Development

```bash
python -m pip install -e '.[dev]'
pytest -q -m 'not integration'
ruff check src tests scripts CRISPRtracrRNA.py
ruff format --check src tests scripts CRISPRtracrRNA.py
mypy
CRISPRTRACRRNA_TEST_CONFIG="$PWD/local.toml" pytest -q -m integration
python -m build
```

Runtime and resource provenance are documented in [THIRD_PARTY.md](THIRD_PARTY.md).

IntaRNA interactions are evaluated in bounded batches sharing the exact oriented
repeat (`--intarna-batch-size 128`, the default). Set the size to `1` for an
explicit serial comparison. The adapter validates every native CSV row and fails
on malformed evidence; it never silently retries a failed batch.

An experimental Type II complete-mode option, `--short-anti-repeat-rescue`, tests
short native genomic alignments using a seed-anchored duplex plus independent
regional model or terminator evidence. It is disabled by default. Its fixed gates,
controls and evaluation protocol are in [the council plan](docs/COUNCIL_IMPROVEMENT_PLAN.md).
Reported windows remain search windows, not inferred native transcript endpoints.

For this local checkout, the tested reproducibility configuration is:

```bash
crisprtracrrna run --config local.reproducible.toml --input genome.fasta --output results
```

It selects a separately built FASTA36 dependency with explicit RNG seeds and one
native thread. The stock 36.3.8g executable can vary its shuffled-background
statistics across identical inputs, which changed the candidate count at one
regression locus. The original failed exact-history comparison remains reported.
The [reproducibility amendment](docs/COUNCIL_REPRODUCIBILITY_AMENDMENT.md) describes
the bounded repair and separately controlled old/new comparison. The existing
`local.toml` and installed native executable are preserved. Do not infer arbitrary
multithread reproducibility from this one-thread profile.

The frozen council evaluation on 79 inspected development loci (78 uniquely
mapped references) localizes 68/78 with defaults and 75/78 with the experimental
option. All original detections are retained; 11 additional hypotheses raise the
total from 3,395 to 3,406. The option remains disabled by default. See
[measured improvements and limitations](docs/IMPROVEMENTS.md#council-round-two-bounded-implementation)
for controls, remaining misses, runtime and reproducibility results, and the
[final council outcome](docs/council/07_council_outcome.md) for the independent
reviews and acceptance scope.
